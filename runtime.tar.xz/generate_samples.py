from pathlib import Path
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib import colors

OUT = Path(__file__).parent / "samples"
OUT.mkdir(exist_ok=True)

CASES = {
    "happy-path": {
        "vendor": "Apex Office Supplies Pvt Ltd", "invoice": "APS-2026-1042", "date": "10/11/2026",
        "po": "PO-1001", "total": "117500.00", "subtotal": "99576.27", "tax": "17923.73",
        "description": "Office chairs, printer paper, and stationery", "note": "Payment terms: Net 30 days"
    },
    "missing-po": {
        "vendor": "Northstar IT Solutions LLP", "invoice": "NIT-2026-7781", "date": "12/11/2026",
        "po": None, "total": "250000.00", "subtotal": "211864.41", "tax": "38135.59",
        "description": "Laptop docking stations and IT accessories", "note": "Purchase order reference not supplied by vendor"
    },
    "amount-variance": {
        "vendor": "BluePeak Logistics", "invoice": "BPL-2026-3308", "date": "13/11/2026",
        "po": "PO-1003", "total": "95000.00", "subtotal": "80508.47", "tax": "14491.53",
        "description": "Freight and warehouse handling services", "note": "Invoice exceeds the approved purchase order amount"
    },
    "duplicate": {
        "vendor": "Apex Office Supplies Pvt Ltd", "invoice": "APS-2026-1042", "date": "10/11/2026",
        "po": "PO-1001", "total": "117500.00", "subtotal": "99576.27", "tax": "17923.73",
        "description": "Office chairs, printer paper, and stationery", "note": "Same business key as the happy-path invoice"
    },
    "vendor-mismatch": {
        "vendor": "Silverline Traders Pvt Ltd", "invoice": "SLT-2026-908", "date": "14/11/2026",
        "po": "PO-1002", "total": "248000.00", "subtotal": "210169.49", "tax": "37830.51",
        "description": "IT equipment and peripherals", "note": "Invoice vendor does not match the vendor approved on the PO"
    },
}

for name, d in CASES.items():
    path = OUT / f"{name}.pdf"
    c = canvas.Canvas(str(path), pagesize=A4)
    width, height = A4
    c.setFillColor(colors.HexColor('#1d3550'))
    c.rect(0, height-92, width, 92, fill=1, stroke=0)
    c.setFillColor(colors.white)
    c.setFont('Helvetica-Bold', 18)
    c.drawString(46, height-48, 'TAX INVOICE')
    c.setFont('Helvetica', 9)
    c.drawRightString(width-46, height-48, 'SYNTHETIC CASE-STUDY DOCUMENT')
    y = height-130
    c.setFillColor(colors.HexColor('#253548'))
    c.setFont('Helvetica-Bold', 11)
    c.drawString(46, y, f"Vendor: {d['vendor']}")
    y -= 20
    c.setFont('Helvetica', 9)
    c.setFillColor(colors.HexColor('#526273'))
    c.drawString(46, y, 'Vendor billing department')
    c.drawString(46, y-14, 'India')
    c.setFillColor(colors.HexColor('#253548'))
    c.setFont('Helvetica-Bold', 9)
    c.drawString(width-220, height-130, f"Invoice Number: {d['invoice']}")
    c.drawString(width-220, height-148, f"Invoice Date: {d['date']}")
    if d['po']:
        c.drawString(width-220, height-166, f"PO Number: {d['po']}")
    c.setStrokeColor(colors.HexColor('#d8e0e8'))
    c.line(46, height-205, width-46, height-205)
    y = height-238
    c.setFont('Helvetica-Bold', 9)
    c.setFillColor(colors.HexColor('#637386'))
    c.drawString(46, y, 'DESCRIPTION')
    c.drawRightString(width-46, y, 'AMOUNT (INR)')
    c.setStrokeColor(colors.HexColor('#e3e8ed'))
    c.line(46, y-9, width-46, y-9)
    y -= 34
    c.setFont('Helvetica', 10)
    c.setFillColor(colors.HexColor('#253548'))
    c.drawString(46, y, d['description'])
    c.drawRightString(width-46, y, d['subtotal'])
    y -= 28
    c.drawString(46, y, 'GST (18%)')
    c.drawRightString(width-46, y, d['tax'])
    y -= 20
    c.line(330, y, width-46, y)
    y -= 26
    c.setFont('Helvetica-Bold', 11)
    c.drawString(330, y, 'Total Due:')
    c.drawRightString(width-46, y, f"INR {d['total']}")
    y -= 65
    c.setFont('Helvetica', 9)
    c.setFillColor(colors.HexColor('#69798a'))
    c.drawString(46, y, d['note'])
    c.drawString(46, y-18, 'This invoice is synthetic and prepared only for workflow testing.')
    c.setStrokeColor(colors.HexColor('#d8e0e8'))
    c.line(46, 55, width-46, 55)
    c.setFont('Helvetica', 8)
    c.drawString(46, 38, 'ClearPay synthetic test data · No real vendor, payment, or tax liability')
    c.save()
    print(path)
