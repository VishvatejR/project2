const $ = (id) => document.getElementById(id);
let selectedFile = null;
let currentRunId = null;

function toast(message, error=false){
  const el = $('toast'); el.textContent = message; el.classList.remove('hidden','error');
  if(error) el.classList.add('error'); setTimeout(()=>el.classList.add('hidden'),4200);
}
function esc(value){return String(value ?? '—').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function formatMoney(amount,currency='INR'){if(amount===null||amount===undefined||amount==='')return '—';let n=Number(amount);return `${currency} ${n.toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2})}`;}
function statusLabel(status){return status==='APPROVED'?'APPROVED':status==='BLOCKED'?'BLOCKED':'NEEDS REVIEW';}
function showResult(run){
  currentRunId = run.run_id || run.id;
  $('emptyRun').classList.add('hidden'); $('runResult').classList.remove('hidden');
  const f=run.fields||run.detail?.fields||{}; const d=run.decision||run.detail?.decision||{}; const stages=run.stages||run.detail?.stages||[];
  $('runSummary').innerHTML=`<b>Run #${esc(currentRunId)} · ${esc(run.filename||'invoice PDF')}</b><span>${esc(run.extraction_method||run.detail?.extraction_method||'PDF extraction')}</span>`;
  $('timeline').innerHTML=stages.map((s,i)=>`<div class="stage"><div class="stage-dot">✓</div><div><b>${esc(s.name)}</b><small>${esc(s.detail)}</small></div></div>`).join('');
  const cls=d.status==='APPROVED'?'approved':d.status==='BLOCKED'?'blocked':'needs-review';
  const checks=(d.checks||[]).map(c=>`<li><b>${c.passed===true?'Pass':c.passed===false?'Flag':'Info'} · ${esc(c.name)}:</b> ${esc(c.detail)}</li>`).join('');
  $('decisionBox').className=`decision-box ${cls}`;
  $('decisionBox').innerHTML=`<div class="decision-title">${esc(d.decision_label||statusLabel(d.status))} · ${esc(statusLabel(d.status))}</div><p>${esc((d.reasons||[]).join(' '))}</p><ul>${checks}</ul>`;
  const entries=[['Vendor',f.vendor_name],['Invoice number',f.invoice_number],['Invoice date',f.invoice_date],['PO reference',f.po_number],['Invoice total',formatMoney(f.total_amount,f.currency)],['Extraction confidence',f.extraction_confidence]];
  $('fieldGrid').innerHTML=entries.map(([k,v])=>`<div class="field"><label>${esc(k)}</label><b>${esc(v||'Not detected')}</b></div>`).join('');
  const needsManual=d.status!=='APPROVED'; $('reviewBox').classList.toggle('hidden',!needsManual);
  $('reviewReason').value='';
  refreshHistory(); refreshDashboard();
}
async function refreshDashboard(){
  const r=await fetch('/api/dashboard'); if(!r.ok)return; const d=await r.json();
  $('totalRuns').textContent=d.total_runs; $('approvedRuns').textContent=d.approved; $('reviewRuns').textContent=d.needs_review; $('blockedRuns').textContent=d.blocked; $('poCount').textContent=`${d.po_count} RECORDS`;
}
async function refreshHistory(){
  const r=await fetch('/api/runs?limit=50'); if(!r.ok)return; const rows=await r.json();
  $('historyBody').innerHTML=rows.length?rows.map(x=>`<tr><td><span class="run-id">#${x.id}</span></td><td><span class="vendor-main">${esc(x.vendor_name||'Unidentified vendor')}</span><span class="vendor-sub">${esc(x.invoice_number||'No invoice number')} · ${esc(x.filename)}</span></td><td>${esc(x.po_number||'—')}</td><td>${formatMoney(x.total_amount,x.currency)}</td><td><span class="status-pill ${esc(x.status)}">${statusLabel(x.status)}</span></td><td>${new Date(x.created_at).toLocaleString()}</td></tr>`).join(''):'<tr><td colspan="6" class="table-empty">No runs yet. Process a sample invoice to populate the audit trail.</td></tr>';
}
async function refreshPOs(){
  const r=await fetch('/api/purchase-orders'); if(!r.ok)return; const rows=await r.json();
  $('poBody').innerHTML=rows.map(x=>`<tr><td><b>${esc(x.po_number)}</b></td><td>${esc(x.vendor_name)}</td><td>${formatMoney(x.approved_amount,x.currency)}</td><td>${esc(x.currency)}</td><td><span class="po-status" style="${x.status==='APPROVED'?'':'background:#fff4df;color:#a96b08'}">${esc(x.status)}</span></td><td>${esc(x.description)}</td></tr>`).join('');
}
function beginProgress(filename){
  $('emptyRun').classList.add('hidden'); $('runResult').classList.remove('hidden');
  $('runSummary').innerHTML=`<b>Processing · ${esc(filename)}</b><span>Receiving backend stage events…</span>`;
  $('timeline').innerHTML=''; $('decisionBox').className='decision-box hidden'; $('fieldGrid').innerHTML=''; $('reviewBox').classList.add('hidden');
}
function appendProgressStage(stage){
  const el=document.createElement('div'); el.className='stage';
  el.innerHTML=`<div class="stage-dot">✓</div><div><b>${esc(stage.name)}</b><small>${esc(stage.detail)}</small></div>`;
  $('timeline').appendChild(el);
}
async function consumeStream(url, options, filename){
  beginProgress(filename);
  const response=await fetch(url,options);
  if(!response.ok){let payload={};try{payload=await response.json()}catch{}throw new Error(payload.detail||'The workflow request failed');}
  const reader=response.body.getReader(); const decoder=new TextDecoder(); let buffer=''; let finalResult=null;
  while(true){
    const {value,done}=await reader.read(); if(done)break; buffer+=decoder.decode(value,{stream:true});
    let boundary;
    while((boundary=buffer.indexOf('\n\n'))>=0){
      const block=buffer.slice(0,boundary); buffer=buffer.slice(boundary+2);
      const event=(block.match(/^event:\s*(.+)$/m)||[])[1]; const data=(block.match(/^data:\s*(.+)$/m)||[])[1]; if(!data)continue;
      const payload=JSON.parse(data);
      if(event==='stage') appendProgressStage(payload);
      else if(event==='result') finalResult=payload;
      else if(event==='error') throw new Error(payload.detail||'Workflow failed');
    }
  }
  if(!finalResult)throw new Error('The server closed the run stream without a final result.');
  return finalResult;
}
async function processUpload(){
  if(!selectedFile)return; const fd=new FormData(); fd.append('file',selectedFile); $('processBtn').disabled=true; $('processBtn').textContent='Processing invoice…';
  try{const data=await consumeStream('/api/process-stream',{method:'POST',body:fd},selectedFile.name);showResult(data);toast(`Invoice processed. Outcome: ${statusLabel(data.decision.status)}.`);}
  catch(e){toast(e.message,true);}finally{$('processBtn').disabled=false;$('processBtn').innerHTML='Run invoice checks <span>→</span>';}
}
async function runScenario(name){
  document.querySelectorAll('.scenario-btn').forEach(b=>b.disabled=true);
  try{const data=await consumeStream(`/api/demo/${name}/stream`,{method:'POST'},`${name}.pdf`);showResult(data);toast(`Scenario complete: ${statusLabel(data.decision.status)}.`);}
  catch(e){toast(e.message,true);}finally{document.querySelectorAll('.scenario-btn').forEach(b=>b.disabled=false);}
}
$('invoiceFile').addEventListener('change',e=>{selectedFile=e.target.files[0]||null;$('selectedFile').textContent=selectedFile?selectedFile.name:'No file selected';$('processBtn').disabled=!selectedFile;});
$('processBtn').addEventListener('click',processUpload);
document.querySelectorAll('.scenario-btn').forEach(b=>b.addEventListener('click',()=>runScenario(b.dataset.scenario)));
$('refreshBtn').addEventListener('click',()=>{refreshDashboard();refreshHistory();refreshPOs();toast('Dashboard refreshed.');});
const dz=$('dropZone');dz.addEventListener('dragover',e=>{e.preventDefault();dz.classList.add('drag');});dz.addEventListener('dragleave',()=>dz.classList.remove('drag'));dz.addEventListener('drop',e=>{e.preventDefault();dz.classList.remove('drag');const file=e.dataTransfer.files[0];if(file){if(file.type!=='application/pdf'&&!file.name.toLowerCase().endsWith('.pdf')){toast('Please drop a PDF file.',true);return;}selectedFile=file;$('selectedFile').textContent=file.name;$('processBtn').disabled=false;}});
async function saveManual(outcome){
  const reason=$('reviewReason').value.trim();if(reason.length<8){toast('Add a reviewer rationale of at least 8 characters.',true);return;}
  try{const r=await fetch(`/api/runs/${currentRunId}/review`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({outcome,reason})});const d=await r.json();if(!r.ok)throw new Error(d.detail||'Review could not be saved');toast('Manual review recorded in the audit trail.');refreshHistory();}
  catch(e){toast(e.message,true);}
}
$('approveReview').addEventListener('click',()=>saveManual('APPROVED_MANUALLY'));
$('rejectReview').addEventListener('click',()=>saveManual('REJECTED_MANUALLY'));
refreshDashboard();refreshHistory();refreshPOs();
