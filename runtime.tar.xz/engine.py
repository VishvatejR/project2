"""Deterministic invoice-to-PO decision engine for the ASA case study demo."""
from __future__ import annotations

import hashlib
import io
import re
import time
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
from typing import Any

from ai_extractor import enhance_fields_with_gemini

import fitz  # PyMuPDF


class InvoiceProcessingError(Exception):
    pass


def _normalise_name(value: str | None) -> str:
    if not value:
        return ""
    value = value.lower().strip()
    value = re.sub(r"\b(private limited|pvt\.? ltd\.?|limited|ltd\.?|llp|incorporated|inc\.?)\b", "", value)
    return re.sub(r"[^a-z0-9]", "", value)


def _parse_money(value: str | None) -> Decimal | None:
    if not value:
        return None
    cleaned = value.replace(",", "").strip()
    try:
        return Decimal(cleaned).quantize(Decimal("0.01"))
    except (InvalidOperation, ValueError):
        return None


def _field(patterns: list[str], text: str, flags: int = re.IGNORECASE | re.MULTILINE) -> str | None:
    for pattern in patterns:
        match = re.search(pattern, text, flags)
        if match:
            return match.group(1).strip().splitlines()[0].strip()
    return None


def extract_pdf_text(pdf_bytes: bytes) -> tuple[str, str]:
    """Extract text from a PDF. Try OCR if available; otherwise flag scan for review."""
    try:
        doc = fitz.open(stream=pdf_bytes, filetype="pdf")
    except Exception as exc:
        raise InvoiceProcessingError(f"The uploaded file could not be opened as a PDF: {exc}") from exc

    pages = []
    for page in doc:
        pages.append(page.get_text("text") or "")
    text = "\n".join(pages).strip()
    method = "PDF text layer"

    if len(re.sub(r"\s", "", text)) < 30:
        # Optional OCR path. We never silently pretend an image-only PDF was read.
        try:
            import pytesseract
            from PIL import Image
            ocr_pages = []
            for page in doc:
                pix = page.get_pixmap(matrix=fitz.Matrix(2, 2), alpha=False)
                image = Image.open(io.BytesIO(pix.tobytes("png")))
                ocr_pages.append(pytesseract.image_to_string(image))
            ocr_text = "\n".join(ocr_pages).strip()
            if len(re.sub(r"\s", "", ocr_text)) > 30:
                text = ocr_text
                method = "OCR (Tesseract)"
            else:
                method = "No readable text; OCR yielded insufficient text"
        except Exception:
            method = "Scanned/image PDF; OCR dependency unavailable"
    doc.close()
    return text, method


def extract_invoice_fields(text: str) -> dict[str, Any]:
    vendor = _field([
        r"^(?:Vendor|Supplier|Seller|From)\s*:\s*(.+)$",
        r"^(?:Vendor|Supplier)\s+Name\s*:\s*(.+)$",
    ], text)
    invoice_number = _field([
        r"^Invoice\s*(?:Number|No\.?|#)\s*[:#-]?\s*([A-Z0-9][A-Z0-9_./-]+)$",
        r"^Invoice\s*#\s*([A-Z0-9][A-Z0-9_./-]+)$",
    ], text)
    invoice_date_raw = _field([
        r"^(?:Invoice\s*)?Date\s*:\s*([0-9]{1,2}[/-][0-9]{1,2}[/-][0-9]{2,4}|[0-9]{4}-[0-9]{2}-[0-9]{2})$",
    ], text)
    po_number = _field([
        r"^(?:PO\s*(?:Number|No\.?|#)?|Purchase\s+Order(?:\s+Number|\s+No\.?)?)\s*[:#-]\s*(PO[-A-Z0-9/]+)$",
    ], text)
    currency = _field([
        r"^(?:Currency)\s*:\s*(INR|USD|EUR|GBP|CAD|AUD)$",
    ], text)
    if not currency:
        currency = "INR" if re.search(r"₹|\bINR\b|\bRs\.?\b", text, re.I) else "INR"

    total_raw = _field([
        r"^(?:Grand\s+Total|Total\s+Due|Invoice\s+Total|Total\s+Amount)\s*[:=-]\s*(?:(?:INR|USD|EUR|GBP|Rs\.?|₹)\s*)?([0-9][0-9,]*(?:\.\d{1,2})?)$",
        r"^(?:Grand\s+Total|Total\s+Due|Invoice\s+Total|Total\s+Amount)\s*[:=-]\s*([0-9][0-9,]*(?:\.\d{1,2})?)\s*(?:INR|USD|EUR|GBP)?$",
    ], text)

    invoice_date = None
    if invoice_date_raw:
        for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y", "%d/%m/%y", "%d-%m-%y", "%m/%d/%Y"):
            try:
                invoice_date = datetime.strptime(invoice_date_raw, fmt).date().isoformat()
                break
            except ValueError:
                continue

    total_amount = _parse_money(total_raw)
    return {
        "vendor_name": vendor,
        "invoice_number": invoice_number,
        "invoice_date": invoice_date,
        "invoice_date_raw": invoice_date_raw,
        "po_number": po_number,
        "currency": currency.upper() if currency else None,
        "total_amount": str(total_amount) if total_amount is not None else None,
        "extraction_confidence": "high" if all([vendor, invoice_number, invoice_date, po_number, total_amount is not None]) else "partial",
    }


def decide_invoice(
    fields: dict[str, Any],
    po: dict[str, Any] | None,
    is_duplicate: bool,
    tolerance_pct: Decimal = Decimal("2.0"),
    extraction_method: str = "PDF text layer",
) -> dict[str, Any]:
    reasons: list[str] = []
    checks: list[dict[str, Any]] = []

    def check(name: str, passed: bool | None, detail: str, severity: str = "info"):
        checks.append({"name": name, "passed": passed, "detail": detail, "severity": severity})

    if is_duplicate:
        reasons.append("A previous invoice with the same normalised vendor and invoice number already exists. Automatic payment is blocked.")
        check("Duplicate detection", False, "Matching vendor + invoice number found in run history.", "critical")
        return {"status": "BLOCKED", "decision_label": "Duplicate invoice blocked", "reasons": reasons, "checks": checks, "variance_pct": None, "tolerance_pct": str(tolerance_pct)}
    check("Duplicate detection", True, "No matching vendor + invoice number found in run history.")

    required = ["vendor_name", "invoice_number", "invoice_date", "total_amount"]
    missing = [name for name in required if not fields.get(name)]
    if missing:
        reasons.append("Required invoice information is missing or could not be extracted: " + ", ".join(missing) + ".")
        check("Required fields", False, "Missing: " + ", ".join(missing), "warning")
    else:
        check("Required fields", True, "Vendor, invoice number, invoice date, and total amount were extracted.")

    if extraction_method.startswith("Scanned/") or extraction_method.startswith("No readable"):
        reasons.append("The PDF appears to be image-based and readable text was not extracted. Human verification is required.")
        check("Document readability", False, extraction_method, "warning")
    else:
        check("Document readability", True, f"Text extracted using {extraction_method}.")

    if missing:
        return {"status": "NEEDS_REVIEW", "decision_label": "Manual review required", "reasons": reasons, "checks": checks, "variance_pct": None, "tolerance_pct": str(tolerance_pct)}

    if not fields.get("po_number"):
        reasons.append("No purchase-order reference was found. The AP team must identify the correct PO before payment.")
        check("PO reference", False, "PO number missing from invoice.", "warning")
        return {"status": "NEEDS_REVIEW", "decision_label": "PO reference missing", "reasons": reasons, "checks": checks, "variance_pct": None, "tolerance_pct": str(tolerance_pct)}

    if po is None:
        reasons.append(f"Purchase order {fields['po_number']} was not found in the approved PO register.")
        check("PO lookup", False, f"{fields['po_number']} not found.", "warning")
        return {"status": "NEEDS_REVIEW", "decision_label": "PO not found", "reasons": reasons, "checks": checks, "variance_pct": None, "tolerance_pct": str(tolerance_pct)}
    check("PO lookup", True, f"Matched {po['po_number']} in the approved PO register.")

    po_status = str(po.get("status", "APPROVED")).upper()
    if po_status == "PENDING":
        reasons.append("The matched purchase order is still pending approval. Do not approve the invoice until the PO owner completes the approval.")
        check("PO approval status", False, "PO is pending approval.", "warning")
        return {"status": "NEEDS_REVIEW", "decision_label": "PO approval pending", "reasons": reasons, "checks": checks, "variance_pct": None, "tolerance_pct": str(tolerance_pct)}
    if po_status != "APPROVED":
        reasons.append(f"The matched purchase order is not approved (status: {po_status}).")
        check("PO approval status", False, f"PO status is {po_status}.", "critical")
        return {"status": "BLOCKED", "decision_label": "PO is not approved", "reasons": reasons, "checks": checks, "variance_pct": None, "tolerance_pct": str(tolerance_pct)}
    check("PO approval status", True, "Purchase order is marked approved.")

    invoice_vendor = _normalise_name(fields.get("vendor_name"))
    po_vendor = _normalise_name(po.get("vendor_name"))
    vendor_match = invoice_vendor == po_vendor
    if not vendor_match:
        reasons.append(f"Vendor mismatch: invoice says '{fields['vendor_name']}', while {po['po_number']} is approved for '{po['vendor_name']}'.")
        check("Vendor match", False, "Invoice vendor does not match the PO vendor.", "critical")
        return {"status": "BLOCKED", "decision_label": "Vendor mismatch blocked", "reasons": reasons, "checks": checks, "variance_pct": None, "tolerance_pct": str(tolerance_pct)}
    check("Vendor match", True, "Invoice vendor matches the PO vendor after normalising legal suffixes and punctuation.")

    invoice_currency = (fields.get("currency") or "INR").upper()
    po_currency = (po.get("currency") or "INR").upper()
    if invoice_currency != po_currency:
        reasons.append(f"Currency mismatch: invoice is {invoice_currency}, but the PO is {po_currency}.")
        check("Currency match", False, f"Invoice {invoice_currency} vs PO {po_currency}.", "warning")
        return {"status": "NEEDS_REVIEW", "decision_label": "Currency mismatch", "reasons": reasons, "checks": checks, "variance_pct": None, "tolerance_pct": str(tolerance_pct)}
    check("Currency match", True, f"Both invoice and PO use {invoice_currency}.")

    invoice_amount = Decimal(str(fields["total_amount"]))
    po_amount = Decimal(str(po["approved_amount"]))
    if po_amount <= 0:
        reasons.append("The PO amount is invalid or non-positive. Human review is required.")
        check("Amount validation", False, "PO amount must be greater than zero.", "critical")
        return {"status": "NEEDS_REVIEW", "decision_label": "Invalid PO amount", "reasons": reasons, "checks": checks, "variance_pct": None, "tolerance_pct": str(tolerance_pct)}
    variance = (abs(invoice_amount - po_amount) / po_amount * Decimal("100")).quantize(Decimal("0.01"))
    within = variance <= tolerance_pct
    check("Amount tolerance", within, f"Invoice {invoice_currency} {invoice_amount:,.2f}; PO {po_currency} {po_amount:,.2f}; variance {variance}% against {tolerance_pct}% tolerance.", "warning" if not within else "info")
    if not within:
        reasons.append(f"Invoice amount differs from the PO by {variance}%, exceeding the configured ±{tolerance_pct}% tolerance. AP review is required.")
        return {"status": "NEEDS_REVIEW", "decision_label": "Amount outside tolerance", "reasons": reasons, "checks": checks, "variance_pct": str(variance), "tolerance_pct": str(tolerance_pct)}

    reasons.append(f"All mandatory checks passed. Amount variance of {variance}% is within the configured ±{tolerance_pct}% tolerance. Recommended outcome: approve for payment, subject to normal AP controls.")
    return {"status": "APPROVED", "decision_label": "Approved for payment review", "reasons": reasons, "checks": checks, "variance_pct": str(variance), "tolerance_pct": str(tolerance_pct)}


def build_run(pdf_bytes: bytes, filename: str, po_records: list[dict[str, Any]], prior_invoice_keys: set[tuple[str, str]], tolerance_pct: Decimal, on_stage=None) -> dict[str, Any]:
    stages: list[dict[str, Any]] = []

    def stage(name: str, detail: str, state: str = "completed"):
        item = {"name": name, "status": state, "detail": detail, "completed_at": datetime.now(timezone.utc).isoformat(timespec="milliseconds")}
        stages.append(item)
        if on_stage:
            on_stage(item)

    digest = hashlib.sha256(pdf_bytes).hexdigest()
    stage("Input received", f"Accepted {filename} ({len(pdf_bytes):,} bytes); SHA-256 fingerprint recorded.")
    text, extraction_method = extract_pdf_text(pdf_bytes)
    stage("PDF text extraction", f"{len(text):,} characters extracted using {extraction_method}.")
    fields = extract_invoice_fields(text)
    fields, ai_used, ai_note = enhance_fields_with_gemini(text, fields)
    if ai_used and all(fields.get(k) for k in ("vendor_name", "invoice_number", "invoice_date", "po_number", "total_amount")):
        fields["extraction_confidence"] = "high"
    stage("Field extraction", f"Extracted vendor, invoice number, date, PO reference, currency, and total where available. Confidence: {fields['extraction_confidence']}. {ai_note}.")

    key = (_normalise_name(fields.get("vendor_name")), (fields.get("invoice_number") or "").strip().upper())
    is_duplicate = bool(key[0] and key[1] and key in prior_invoice_keys)
    stage("Duplicate detection", "Duplicate business key found." if is_duplicate else "No prior matching vendor + invoice number found.")

    po = None
    if fields.get("po_number"):
        po = next((item for item in po_records if item["po_number"].strip().upper() == fields["po_number"].strip().upper()), None)
    stage("Purchase order matching", f"Matched {po['po_number']} for {po['vendor_name']}." if po else (f"PO {fields.get('po_number')} not found." if fields.get("po_number") else "No PO reference extracted."))

    decision = decide_invoice(fields, po, is_duplicate, tolerance_pct, extraction_method)
    stage("Business-rule evaluation", f"Final status: {decision['status']}. {decision['decision_label']}.")
    stage("Audit record", "Decision, evidence, checks, source filename, and document fingerprint are ready to persist.")

    return {
        "filename": filename,
        "sha256": digest,
        "extracted_text": text,
        "extraction_method": extraction_method,
        "ai_assisted": ai_used,
        "fields": fields,
        "po_match": po,
        "decision": decision,
        "stages": stages,
    }
