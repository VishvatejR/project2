from __future__ import annotations

import asyncio
import csv
import json
import io
import os
from contextlib import asynccontextmanager
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any

from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.responses import HTMLResponse, Response, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from database import dashboard_stats, get_duplicate_keys, get_run, init_db, list_runs, record_review, save_run
from engine import InvoiceProcessingError, build_run

BASE_DIR = Path(__file__).parent
PO_FILE = BASE_DIR / "data" / "purchase_orders.csv"
SAMPLES_DIR = BASE_DIR / "samples"
MAX_UPLOAD_BYTES = 8 * 1024 * 1024
TOLERANCE_PCT = Decimal(os.getenv("PO_TOLERANCE_PCT", "2.0"))

def _stream_response(content: bytes, filename: str) -> StreamingResponse:
    async def event_generator():
        queue: asyncio.Queue = asyncio.Queue()
        loop = asyncio.get_running_loop()

        def publish(kind: str, payload: Any):
            loop.call_soon_threadsafe(queue.put_nowait, (kind, payload))

        def worker():
            try:
                result = _process_bytes(content, filename, on_stage=lambda stage: publish("stage", stage))
                publish("result", result)
            except HTTPException as exc:
                publish("error", {"detail": exc.detail, "status_code": exc.status_code})
            except Exception as exc:
                publish("error", {"detail": f"Unexpected processing error: {type(exc).__name__}", "status_code": 500})
            finally:
                publish("end", {})

        task = asyncio.create_task(asyncio.to_thread(worker))
        while True:
            item = await queue.get()
            if item is None:
                break
            kind, payload = item
            if kind == "end":
                break
            yield f"event: {kind}\ndata: {json.dumps(payload, ensure_ascii=False)}\n\n"
        await task

    return StreamingResponse(event_generator(), media_type="text/event-stream", headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


@asynccontextmanager
async def lifespan(_app):
    init_db()
    if not any(SAMPLES_DIR.glob("*.pdf")):
        # On platforms that receive only source files, generate the synthetic PDFs at startup.
        import generate_samples  # noqa: F401
    yield


app = FastAPI(
    title="ClearPay | Invoice-to-PO Decision Desk",
    description="A deterministic, auditable invoice intake and purchase-order matching workflow for the ASA case study.",
    version="1.0.0",
    lifespan=lifespan,
)
app.mount("/static", StaticFiles(directory=BASE_DIR / "static"), name="static")
app.mount("/samples", StaticFiles(directory=SAMPLES_DIR), name="samples")


class ReviewRequest(BaseModel):
    outcome: str = Field(pattern="^(APPROVED_MANUALLY|REJECTED_MANUALLY)$")
    reason: str = Field(min_length=8, max_length=1000)


def load_pos() -> list[dict[str, Any]]:
    with PO_FILE.open(newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    for row in rows:
        try:
            row["approved_amount"] = str(Decimal(row["approved_amount"]).quantize(Decimal("0.01")))
        except (InvalidOperation, KeyError):
            row["approved_amount"] = "0.00"
    return rows


def _process_bytes(content: bytes, filename: str, on_stage=None) -> dict[str, Any]:
    if not content.startswith(b"%PDF"):
        raise HTTPException(status_code=400, detail="The file does not have a valid PDF header.")
    if not content:
        raise HTTPException(status_code=400, detail="The uploaded file is empty.")
    try:
        run = build_run(content, filename, load_pos(), get_duplicate_keys(), TOLERANCE_PCT, on_stage=on_stage)
    except InvoiceProcessingError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    run_id = save_run(run)
    return {"run_id": run_id, **run}


@app.get("/", response_class=HTMLResponse)
def index():
    return (BASE_DIR / "static" / "index.html").read_text(encoding="utf-8")


@app.get("/api/health")
def health():
    return {"status": "ok", "service": "ClearPay", "po_records": len(load_pos()), "tolerance_pct": str(TOLERANCE_PCT), "gemini_configured": bool(os.getenv("GEMINI_API_KEY"))}


@app.get("/api/dashboard")
def dashboard():
    return {**dashboard_stats(), "tolerance_pct": str(TOLERANCE_PCT), "po_count": len(load_pos())}


@app.get("/api/purchase-orders")
def purchase_orders():
    return load_pos()


@app.get("/api/runs")
def runs(limit: int = 50):
    if not 1 <= limit <= 200:
        raise HTTPException(status_code=400, detail="limit must be between 1 and 200")
    return list_runs(limit)


@app.get("/api/runs/{run_id}")
def run_detail(run_id: int):
    result = get_run(run_id)
    if not result:
        raise HTTPException(status_code=404, detail="Run not found")
    return result


@app.post("/api/process")
async def process_invoice(file: UploadFile = File(...)):
    filename = Path(file.filename or "invoice.pdf").name
    if not filename.lower().endswith(".pdf"):
        raise HTTPException(status_code=400, detail="Please upload a PDF invoice.")
    content = await file.read(MAX_UPLOAD_BYTES + 1)
    if len(content) > MAX_UPLOAD_BYTES:
        raise HTTPException(status_code=413, detail="Maximum file size is 8 MB.")
    return _process_bytes(content, filename)


@app.post("/api/process-stream")
async def process_invoice_stream(file: UploadFile = File(...)):
    filename = Path(file.filename or "invoice.pdf").name
    if not filename.lower().endswith(".pdf"):
        raise HTTPException(status_code=400, detail="Please upload a PDF invoice.")
    content = await file.read(MAX_UPLOAD_BYTES + 1)
    if len(content) > MAX_UPLOAD_BYTES:
        raise HTTPException(status_code=413, detail="Maximum file size is 8 MB.")
    if not content.startswith(b"%PDF"):
        raise HTTPException(status_code=400, detail="The file does not have a valid PDF header.")
    return _stream_response(content, filename)


@app.post("/api/demo/{scenario}/stream")
def run_demo_stream(scenario: str):
    allowed = {"happy-path", "missing-po", "amount-variance", "duplicate", "vendor-mismatch"}
    if scenario not in allowed:
        raise HTTPException(status_code=404, detail="Unknown demo scenario")
    path = SAMPLES_DIR / f"{scenario}.pdf"
    if not path.exists():
        raise HTTPException(status_code=404, detail="Demo input is not available")
    if scenario == "duplicate":
        prior_keys = get_duplicate_keys()
        if not any(key[1] == "APS-2026-1042" for key in prior_keys):
            prior_path = SAMPLES_DIR / "happy-path.pdf"
            _process_bytes(prior_path.read_bytes(), "historical-prior-invoice.pdf")
    return _stream_response(path.read_bytes(), path.name)


@app.post("/api/demo/{scenario}")
def run_demo(scenario: str):
    allowed = {"happy-path", "missing-po", "amount-variance", "duplicate", "vendor-mismatch"}
    if scenario not in allowed:
        raise HTTPException(status_code=404, detail="Unknown demo scenario")
    path = SAMPLES_DIR / f"{scenario}.pdf"
    if not path.exists():
        raise HTTPException(status_code=404, detail="Demo input is not available")
    if scenario == "duplicate":
        # If no historical copy exists yet, seed one as an imported prior invoice so the duplicate case is reproducible.
        prior_keys = get_duplicate_keys()
        if not any(key[1] == "APS-2026-1042" for key in prior_keys):
            prior_path = SAMPLES_DIR / "happy-path.pdf"
            _process_bytes(prior_path.read_bytes(), "historical-prior-invoice.pdf")
    return _process_bytes(path.read_bytes(), path.name)


@app.post("/api/runs/{run_id}/review")
def review_run(run_id: int, payload: ReviewRequest):
    current = get_run(run_id)
    if not current:
        raise HTTPException(status_code=404, detail="Run not found")
    ok = record_review(run_id, payload.outcome, payload.reason.strip())
    if not ok:
        raise HTTPException(status_code=500, detail="Could not save review")
    return {"run_id": run_id, "review_status": payload.outcome, "review_reason": payload.reason.strip()}


@app.get("/api/export.csv")
def export_csv():
    records = list_runs(200)
    buffer = io.StringIO()
    fields = ["id", "created_at", "filename", "vendor_name", "invoice_number", "po_number", "total_amount", "currency", "status", "decision_label", "review_status"]
    writer = csv.DictWriter(buffer, fieldnames=fields, extrasaction="ignore")
    writer.writeheader()
    writer.writerows(records)
    return Response(buffer.getvalue(), media_type="text/csv", headers={"Content-Disposition": "attachment; filename=clearpay-run-history.csv"})
