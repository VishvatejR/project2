from __future__ import annotations
import json
import sqlite3
from pathlib import Path
from typing import Any

DB_PATH = Path(__file__).parent / "data" / "invoice_runs.db"


def connect():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with connect() as conn:
        conn.execute("""CREATE TABLE IF NOT EXISTS runs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at TEXT NOT NULL,
            filename TEXT NOT NULL,
            sha256 TEXT NOT NULL,
            vendor_name TEXT,
            invoice_number TEXT,
            invoice_date TEXT,
            po_number TEXT,
            total_amount TEXT,
            currency TEXT,
            status TEXT NOT NULL,
            decision_label TEXT NOT NULL,
            detail_json TEXT NOT NULL,
            review_status TEXT,
            review_reason TEXT
        )""")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_runs_vendor_invoice ON runs(vendor_name, invoice_number)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_runs_created ON runs(created_at DESC)")


def get_duplicate_keys() -> set[tuple[str, str]]:
    from engine import _normalise_name
    with connect() as conn:
        rows = conn.execute("SELECT vendor_name, invoice_number FROM runs WHERE vendor_name IS NOT NULL AND invoice_number IS NOT NULL").fetchall()
    return {(_normalise_name(r["vendor_name"]), r["invoice_number"].strip().upper()) for r in rows if r["vendor_name"] and r["invoice_number"]}


def save_run(run: dict[str, Any]) -> int:
    from datetime import datetime, timezone
    fields = run["fields"]
    decision = run["decision"]
    with connect() as conn:
        cur = conn.execute("""INSERT INTO runs
          (created_at, filename, sha256, vendor_name, invoice_number, invoice_date, po_number, total_amount, currency, status, decision_label, detail_json)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""", (
            datetime.now(timezone.utc).isoformat(timespec="seconds"), run["filename"], run["sha256"],
            fields.get("vendor_name"), fields.get("invoice_number"), fields.get("invoice_date"), fields.get("po_number"),
            fields.get("total_amount"), fields.get("currency"), decision["status"], decision["decision_label"],
            json.dumps(run, ensure_ascii=False)
        ))
        return int(cur.lastrowid)


def list_runs(limit: int = 50) -> list[dict[str, Any]]:
    with connect() as conn:
        rows = conn.execute("SELECT id, created_at, filename, vendor_name, invoice_number, po_number, total_amount, currency, status, decision_label, review_status FROM runs ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
    return [dict(r) for r in rows]


def get_run(run_id: int) -> dict[str, Any] | None:
    with connect() as conn:
        row = conn.execute("SELECT * FROM runs WHERE id = ?", (run_id,)).fetchone()
    if not row:
        return None
    data = dict(row)
    data["detail"] = json.loads(data.pop("detail_json"))
    return data


def dashboard_stats() -> dict[str, Any]:
    with connect() as conn:
        total = conn.execute("SELECT COUNT(*) FROM runs").fetchone()[0]
        rows = conn.execute("SELECT status, COUNT(*) AS n FROM runs GROUP BY status").fetchall()
        review = conn.execute("SELECT COUNT(*) FROM runs WHERE status='NEEDS_REVIEW'").fetchone()[0]
        blocked = conn.execute("SELECT COUNT(*) FROM runs WHERE status='BLOCKED'").fetchone()[0]
        approved = conn.execute("SELECT COUNT(*) FROM runs WHERE status='APPROVED'").fetchone()[0]
    return {"total_runs": total, "approved": approved, "needs_review": review, "blocked": blocked, "by_status": {r["status"]: r["n"] for r in rows}}


def record_review(run_id: int, outcome: str, reason: str) -> bool:
    with connect() as conn:
        cur = conn.execute("UPDATE runs SET review_status=?, review_reason=? WHERE id=?", (outcome, reason, run_id))
        return cur.rowcount > 0
